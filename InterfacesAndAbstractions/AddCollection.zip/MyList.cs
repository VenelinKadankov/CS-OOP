﻿using System.Collections.Generic;

namespace CollectionHierarchy
{
    public class MyList : ICustomList
    {
        public MyList()
        {
            this.Items = new List<string>(100);
        }

        public int Used => Items.Count;

        public List<string> Items { get; private set; }
        public string Remove()
        {
            string item = Items[0];
            this.Items.RemoveAt(0);

            return item;
        }

        public int Add(string item)
        {
            this.Items.Insert(0, item);

            return 0;
        }
    }
}
