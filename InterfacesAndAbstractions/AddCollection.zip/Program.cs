﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CollectionHierarchy
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] items = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);

            int[] resultAddCollection = new int[items.Length];
            int[] resultRemoveCollection = new int[items.Length];
            int[] resultList = new int[items.Length];

            AddCollection first = new AddCollection();
            AddRemoveCollection second = new AddRemoveCollection();
            MyList third = new MyList();

            for (int i = 0; i < items.Length; i++)
            {
                resultAddCollection[i] = first.Add(items[i]);
                resultRemoveCollection[i] = second.Add(items[i]);
                resultList[i] = third.Add(items[i]);
            }

            int removeCount = int.Parse(Console.ReadLine());

            string[] resultFirst = new string[removeCount];
            string[] resultSecond = new string[removeCount];

            for (int i = 0; i < removeCount; i++)
            {
                resultFirst[i] = second.Remove();
                resultSecond[i] = third.Remove();
            }

            Console.WriteLine(string.Join(" ", resultAddCollection));
            Console.WriteLine(string.Join(" ", resultRemoveCollection));
            Console.WriteLine(string.Join(" ", resultList));
            Console.WriteLine(string.Join(" ", resultFirst));
            Console.WriteLine(string.Join(" ", resultSecond));
        }
    }
}
