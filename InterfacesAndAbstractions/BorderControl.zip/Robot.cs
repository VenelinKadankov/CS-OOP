﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public class Robot : IIdable
    {
        public Robot(string model, string id)
        {
            this.Model = model;
            this.Id = id;
        }

        public string Model { get; set; }
        public string Id { get; private set; }

        public string Birthday { get; private set; }

        public bool ValidityCheck(string fakeEnd)
        {
            return this.Id.EndsWith(fakeEnd);
        }

        public bool ValidityCheckBirthday(string year)
        {
            throw new NotImplementedException();
        }
    }
}
