﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public class Pet : IIdable
    {
        public Pet(string name, string birthday)
        {
            this.Name = name;
            this.Birthday = birthday;
        }

        public string Name { get; private set; }
        public string Id { get; private set; }
        public string Birthday { get; private set; }

        public bool ValidityCheck(string fakeEnd)
        {
            return this.Id.EndsWith(fakeEnd);
        }

        public bool ValidityCheckBirthday(string year)
        {
            return this.Birthday.EndsWith(year);
        }
    }
}
