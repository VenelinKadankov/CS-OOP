﻿namespace BorderControl
{
    public interface IIdable
    {
        public string Id { get;}

        public string Birthday { get;}

        public bool ValidityCheck(string fakeEnd);

        public bool ValidityCheckBirthday(string year);
    }
}
