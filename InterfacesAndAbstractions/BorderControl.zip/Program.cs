﻿using System;
using System.Collections.Generic;

namespace BorderControl
{
    public class Program
    {
        static void Main(string[] args)
        {
            int count = int.Parse(Console.ReadLine());

            var allPeople = new Dictionary<string, IBuyer>();

            for (int i = 0; i < count; i++)
            {
                string[] tokens = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);

                string name = tokens[0];

                if (tokens.Length == 4)
                {
                    IBuyer buyer = new Citizen(tokens[0], tokens[1], tokens[2], tokens[3]);

                    if (!allPeople.ContainsKey(name))
                    {
                        allPeople.Add(name, buyer);
                    }
                }
                else if(tokens.Length == 3)
                {
                    IBuyer buyer = new Rebel(tokens[0], tokens[1], tokens[2]);

                    if (!allPeople.ContainsKey(name))
                    {
                        allPeople.Add(name, buyer);
                    }
                }
            }

            string command = Console.ReadLine();

            while (command?.ToUpper() != "END")
            {
                if (allPeople.ContainsKey(command))
                {
                    allPeople[command].BuyFood();
                }

                command = Console.ReadLine();
            }

            int totalFood = 0;

            foreach (var item in allPeople.Values)
            {
                totalFood += item.Food;
            }

            Console.WriteLine(totalFood);
        }
    }
}
